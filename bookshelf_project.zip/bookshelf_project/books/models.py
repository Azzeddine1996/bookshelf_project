from django.db import models
from datetime import datetime
from django.contrib.auth.models import User

# Create your models here.
from django.db import models

class Book(models.Model):
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    published_date = models.DateField(blank=True, null=True)
    category = models.CharField(max_length=50, blank=True, null=True)
    cover_image = models.ImageField(upload_to='book_covers/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True) # set once on creation
    updated_at = models.DateTimeField(auto_now=True) # updated on every save
    created_by = models.ForeignKey(User, related_name='book', on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.title} by {self.author}"
