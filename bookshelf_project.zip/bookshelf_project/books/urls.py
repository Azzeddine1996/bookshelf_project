from django.urls import path
from . import views

urlpatterns = [
    path('books/', views.BookListView.as_view(), name='book_list'),
    path('books/add/', views.AddBookCreateView.as_view(), name='add_books'),
    path('books/<int:book_id>/update/', views.BookUpdateView.as_view(), name='update_books'),
    path('books/<int:book_id>/delete/', views.BookDeleteView.as_view(), name='delete_books'),
    path('books/<int:book_id>/', views.BookDetailView.as_view(), name='book_detail'),
]