from django.shortcuts import render, redirect
from django.views.generic import ListView, CreateView, UpdateView, DeleteView, DetailView
from .models import Book
from .forms import NewBookForm, UpdateBookForm
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from .filters import BookFilter



# Create your views here.

class BookListView(ListView):
    model = Book
    template_name = 'list_book.html' 
    context_object_name = 'ordered_books'
    ordering = ['-created_at']
    paginate_by = 1

    def get_queryset(self):
        # Only return books created by the logged-in user
        base_qs = Book.objects.filter(created_by=self.request.user).order_by('-created_at')
        self.filterset = BookFilter(self.request.GET, queryset=base_qs)
        return self.filterset.qs
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["filter"] = self.filterset
        return context
    
class AddBookCreateView(LoginRequiredMixin, CreateView):
    model = Book
    form_class = NewBookForm
    template_name = 'add_book.html'
    context_object_name = 'book'
    success_url = reverse_lazy('book_list')

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        messages.success(self.request, "Book added successfully.")
        return super().form_valid(form)
    


class BookUpdateView(LoginRequiredMixin, UpdateView):
    model = Book
    form_class = UpdateBookForm
    template_name = 'update_book.html'
    pk_url_kwarg = 'book_id'
    context_object_name = 'updated_book'
    success_url = reverse_lazy('book_list')

    def form_valid(self, form):
        messages.success(self.request, "Book updated successfully.")
        return super().form_valid(form)
    
class BookDeleteView(LoginRequiredMixin, DeleteView):
    model = Book
    template_name = 'delete_book.html'
    pk_url_kwarg = 'book_id'
    context_object_name = 'deleted_book'
    success_url = reverse_lazy('book_list')

    def delete(self, request, *args, **kwargs):
        messages.success(self.request, "Book deleted successfully.")
        return super().delete(request, *args, **kwargs)

    
class BookDetailView(LoginRequiredMixin, DetailView):
    model = Book
    template_name = 'detail_book.html' 
    pk_url_kwarg = 'book_id'
    context_object_name = 'book'

    def get_queryset(self):
        # Only return books created by the logged-in user
        queryset = Book.objects.filter(created_by=self.request.user).order_by('-created_at')
        return queryset

















# class AddBookCreateView(CreateView):
#     model = Book
#     fields = ('title', 'author', 'description', 'published_date', 'category', 'cover_image')
#     template_name = 'add_book.html' 
#     context_object_name = 'book'
#     form = NewBookForm()
#     def form_valid(self, form):
#         book = form.save(commit=False)
#         book = Book.objects.create(
#             title=form.cleaned_data.get('title'),
#             author=form.cleaned_data.get('author'),
#             description=form.cleaned_data.get('description'),
#             published_date=form.cleaned_data.get('published_date'),
#             category=form.cleaned_data.get('category'),
#             cover_image=form.cleaned_data.get('cover_image'),
#             )
#         book.save()
#         return redirect('book_list')