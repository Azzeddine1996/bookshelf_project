import django_filters
from django.db.models import Q
from .models import Book


class BookFilter(django_filters.FilterSet):
    q = django_filters.CharFilter(method='custom_filter', label='Search')
    class Meta:
        model = Book
        fields = []
        
    def custom_filter(self, queryset, name, value):
        return queryset.filter(
            Q(title__icontains=value) | Q(author__icontains=value)
        )