from django import forms
from .models import Book

class NewBookForm(forms.ModelForm):
    published_date = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'})
    )
    class Meta:
        model = Book
        fields = ['title', 'author', 'description', 'published_date', 'category', 'cover_image']  # adjust fields as needed
    
class UpdateBookForm(forms.ModelForm):
    published_date = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'})
    )
    class Meta:
        model = Book
        fields = ['title', 'author', 'description', 'published_date', 'category', 'cover_image']  # adjust fields as needed
